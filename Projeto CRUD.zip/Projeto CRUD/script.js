const itemInput = document.getElementById("input-item");
const botaoSalvarItem = document.getElementById("adicionador-item");
const lista = document.getElementById("lista");

botaoSalvarItem.addEventListener("click", adicionarItem);

function adicionarItem(evento) {
    evento.preventDefault();

    if (itemInput.value.trim() !== "") {
        const itemDaLista = document.createElement("li");
        itemDaLista.innerHTML = `
            <div class="lista-item-container">
                <div>
                    <label>
                        <input type="checkbox" class="input-checkbox">
                        <div class="checkbox-customizado"></div>
                    </label>
                    <p class="texto-item">${itemInput.value}</p>
                </div>
                <div>
                    <button class="item-lista-button remover-button">
                        <img src="./img/delete.svg" alt="remover">
                    </button>
                    <button class="item-lista-button editar-button">
                        <img src="./img/edit.svg" alt="editar">
                    </button>
                </div>
            </div>
            <p class="texto-data">${new Date().toLocaleString("pt-BR")}</p>
        `;

        const checkbox = itemDaLista.querySelector(".input-checkbox");
        const checkboxCustomizado = itemDaLista.querySelector(".checkbox-customizado");
        const textoItem = itemDaLista.querySelector(".texto-item");

        // Adiciona evento de mudança para alternar o estilo do checkbox e do texto
        checkbox.addEventListener("change", function () {
            checkboxCustomizado.classList.toggle("checked");
            textoItem.classList.toggle("checked-item");
        });

        const botaoRemover = itemDaLista.querySelector(".remover-button");
        botaoRemover.addEventListener("click", function () {
            itemDaLista.remove(); // Remove o item da lista
        });
        const botaoEditar = itemDaLista.querySelector(".editar-button");
        botaoEditar.addEventListener("click", function () {
            const novoTexto = prompt("Edite o item:", textoItem.innerText);
            if (novoTexto !== null && novoTexto.trim() !== "") {
                textoItem.innerText = novoTexto; // Atualiza o texto do item
            }
        });

        lista.appendChild(itemDaLista);
        itemInput.value = "";
    }
}
